<html>
<head>
    <title>To-Do App</title>
    <link rel="stylesheet" href="{{ URL::asset('css/style.css') }}" />
</head>
<body>
<div class="container">
    @yield('content')

</div>
</body>
</html>
