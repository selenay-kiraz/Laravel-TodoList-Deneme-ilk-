<?php

$sName = env("DB_HOST", "");
$db_name = env("DB_DATABASE", "somedefaultvalue");
$uName = env("DB_USERNAME", "somedefaultvalue");
$pass = env("DB_PASSWORD", "somedefaultvalue");

try {
    $conn = new PDO("mysql:host=$sName;dbname=$db_name",
        $uName, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
    echo "Connection failed : ". $e->getMessage();
}
