<!<!DOCTYPE HTML>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title> Login Page </title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="frm">
    <form action="index.php" method="post">
        <p>
            <label>Username:</label>
            <input type="text" id="user" name="user" />
        </p>
        <p>
            <label>Password:</label>
            <input type="password" id="pass" name="pass" />
        </p>
        <p>
            <input type="submit" id="btn" name="Login" />
        </p>
    </form>
</div>
</body>
</html>
</HTML>
